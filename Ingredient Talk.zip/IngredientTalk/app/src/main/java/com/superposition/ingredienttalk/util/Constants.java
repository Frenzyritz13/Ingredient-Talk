package com.superposition.ingredienttalk.util;

public class Constants {

    //Preferences
    public static final String MY_PREF = "Share Preferences";
    public static final String IS_LOGGED_IN = "isLoggedIn";
    public static final String USER_TYPE = "user_type";
    public static final String NAME  = "name";
    public static final String EMAIL = "email";
    public static final String UID = "uid";
    public static final String IMAGE_LINK = "image_link";
    public static final String MOBILE = "mobile";


}
